USE [RedBone]
GO

INSERT INTO [main].[LocationType]
(Location, Enabled)
VALUES
('Phoenix', 1);
