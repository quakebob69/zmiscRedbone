USE Redbone
GO

INSERT INTO
	[main].[Entitlement]
	(Entitlementid, EntitlementName, Description, Enabled, SortId)
VALUES
	(2508, 'Fuel-Card-Number', 'Ability to see Fuel Card Number', 1, '4000400000')
	
GO
