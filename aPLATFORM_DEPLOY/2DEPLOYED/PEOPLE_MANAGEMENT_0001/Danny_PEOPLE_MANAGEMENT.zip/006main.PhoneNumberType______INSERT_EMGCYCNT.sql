USE [RedBone]
GO

INSERT INTO [main].[PhoneNumberType]
           ([Description])
     VALUES
           ('Emergency')
GO

