﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Telerik.Web.UI;
using RedbonePlatform.Classes;

namespace RedbonePlatform.Pages.ContainerPages
{
    public partial class PersonEdit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Check Authorization
            Classes.Auth auth = (Classes.Auth)Session["Auth"];
            if (auth == null)
            {
                Response.Redirect("~/Default.aspx?ShowLogin=true", true);
                return;
            }
            else
            {
                if (!auth.Entitlements.Contains(200)) // RedbonePlatform-Main-ManagePeople
                {
                    Response.Redirect("~/AccessDenied.aspx", true);
                    return;
                }
            }

            if (!Page.IsPostBack)
            {
                ApplyUserSettings();
                string PersonId = Request.QueryString["PersonId"];
                string FirstName = Request.QueryString["FirstName"];
                string LastName = Request.QueryString["LastName"];
                
                // for test only
                // if (PersonId == null) PersonId = 5.ToString();

                RadPageView_Personal.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_AddressContact.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_Certifications.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_PersonEdit_FileManagement.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_UserAccess.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_HiringStatusHistory.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_PersonMappings.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_DriverPoints.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_DriverInfo.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_DriverPay.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_PayRates.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_Notes.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_Review.ContentUrl += "?PersonId=" + PersonId;
                RadPageView_PersonPTO.ContentUrl += "?PersonId=" + PersonId;
                //RadPageView_DocumentDates.ContentUrl += "?PersonId=" + PersonId;

                // Grant access accordingly
                ShowHideTabsBasedOnAccess(auth);

                // Action based on new person or editing existing person scenario
                if (Request.QueryString["PersonId"] == "0")
                {
                    this.Title = "Add new Person";
                    RadTabStrip_Main.FindTabByValue("AddressContact").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("Certifications").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("PersonEdit_FileManagement").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("UserAccess").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("HiringStatusHistory").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("PersonMappings").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("DriverPoints").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("DriverInfo").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("DriverPay").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("PayRates").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("Notes").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("Review").Enabled = false;
                    RadTabStrip_Main.FindTabByValue("PersonPTO").Enabled = false;
                    //RadTabStrip_Main.FindTabByValue("DocumentDates").Enabled = false;
                }
                else
                {
                    this.Title = "Edit: " + FirstName + " " + LastName + ", PersonId " + PersonId;

                    // Disable Driver Pay tab when person is not lease operator or owner operator
                    Datasets.dsPartyMaintenanceTableAdapters.QueriesTableAdapter qry = new Datasets.dsPartyMaintenanceTableAdapters.QueriesTableAdapter();
                    Boolean IsPersonLeaseOpOrOwnerOp = false;
                    IsPersonLeaseOpOrOwnerOp = Convert.ToBoolean(qry.sp_PersonIsLeaseOpOrOwnerOp(Convert.ToInt32(PersonId)));
                    RadTabStrip_Main.FindTabByValue("DriverPay").Enabled = !IsPersonLeaseOpOrOwnerOp;
                }
            }
        }

        private void ApplyUserSettings()
        {
            // Set RibbonBar Skin 
            if (Session["GlobalSkin"] is null) Session["GlobalSkin"] = "Black";
            RadSkinManager1.Skin = Session["GlobalSkin"].ToString();
        }

        private void ShowHideTabsBasedOnAccess(Auth auth)
        {
            // RedbonePlatform-ManagePeople-EntitlementsAdmin
            RadTabStrip_Main.FindTabByValue("UserAccess").Visible = auth.Entitlements.Contains(250);

            // RedbonePlatform-ManagePeople-FileManagement
            RadTabStrip_Main.FindTabByValue("PersonEdit_FileManagement").Visible = auth.Entitlements.Contains(210);

            // RedbonePlatform-ManagePeople-FileManagement
            RadTabStrip_Main.FindTabByValue("PersonMappings").Visible = auth.Entitlements.Contains(230);

            // RedbonePlatform-ManagePeople-FileManagement
            RadTabStrip_Main.FindTabByValue("Notes").Visible = auth.Entitlements.Contains(280);

            // RedbonePlatform-ManagePeople-FileManagement
            RadTabStrip_Main.FindTabByValue("PayRates").Visible = auth.Entitlements.Contains(290);

            // Hide the Pay Rates tab if the person being editied is an Admin and the Logged In user is not a RedbonePlatform-ManagePeople-People-AdminPayRates
            Boolean IsPersonAdmin = false;
            Datasets.dsPayRatesTableAdapters.QueriesTableAdapter qry2 = new Datasets.dsPayRatesTableAdapters.QueriesTableAdapter();
            IsPersonAdmin = Convert.ToBoolean(qry2.IsPersonAdmin(Convert.ToInt32(Request.QueryString["PersonId"])));
            if (!auth.Entitlements.Contains(291) && IsPersonAdmin)
                RadTabStrip_Main.FindTabByValue("PayRates").Visible = false;


            // RedbonePlatform-ManagePeople-FileManagement
            RadTabStrip_Main.FindTabByValue("PersonPTO").Visible = auth.Entitlements.Contains(295);

        }
    }
}